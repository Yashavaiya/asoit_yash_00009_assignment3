<?php
$server_name = "localhost";
$username = "root";
$password = "";
$database_name = "feedback form";

$conn = mysqli_connect($server_name, $username, $password, $database_name);
//now check the connection
if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());

}
if (isset($_POST['save'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    $sql_query = "INSERT INTO `feedback_form`(`fullname`, `email`, `phone`, `subject`, `message`) VALUES ('$name','$email','$phone','$subject','$message')";

    if (mysqli_query($conn, $sql_query)) {
        echo "New Details Entry inserted successfully !";
    } else {
        echo "Error: " . $sql . "" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>